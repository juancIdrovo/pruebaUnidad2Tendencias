INSERT INTO `productos` (`descripcion`, `precio`, `cantidad`) VALUES ('quintal arroz', 25.50, 3);
INSERT INTO `productos` (`descripcion`, `precio`, `cantidad`) VALUES ('docena de huevos', 15.75, 2);
INSERT INTO `productos` (`descripcion`, `precio`, `cantidad`) VALUES ('quintal de papas', 55.20, 1);
INSERT INTO `productos` (`descripcion`, `precio`, `cantidad`) VALUES ('cafe sicafe', 7.90, 10);
INSERT INTO `productos` (`descripcion`, `precio`, `cantidad`) VALUES ('gelatina medusa', 30.00, 5);