package com.practica.jsio.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;



@Entity
@Table(name = "productos")
public class Producto {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;
    
    @NotNull
    @Size(max = 100)
    private String descripcion;
    
    @NotNull
    @DecimalMin(value = "0.01", inclusive = true)
    @Digits(integer=10, fraction=2)
    private Double precio;
    
    @NotNull
    @Min(1)
    private Integer cantidad;

    // Transient fields for calculations
    @Transient
    private Double valorCompra;

    @Transient
    private Double descuento;

    @Transient
    private Double iva;

    @Transient
    private Double total;

    // Getters and Setters

    public Long getCodigo() {
        return codigo;
    }

    public void setCodigo(Long codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Double getValorCompra() {
        return precio * cantidad;
    }

    public Double getDescuento() {
        return getValorCompra() > 50 ? getValorCompra() * 0.1 : 0.0;
    }

    public Double getIva() {
        return (getValorCompra() - getDescuento()) * 0.15;
    }

    public Double getTotal() {
        return getValorCompra() - getDescuento() + getIva();
    }

	public void setValorCompra(Double valorCompra) {
		this.valorCompra = valorCompra;
	}

	public void setDescuento(Double descuento) {
		this.descuento = descuento;
	}

	public void setIva(Double iva) {
		this.iva = iva;
	}

	public void setTotal(Double total) {
		this.total = total;
	}
    
    
}

