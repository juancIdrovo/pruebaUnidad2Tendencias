package com.practica.jsio.services;

import java.util.List;


import com.practica.jsio.entity.Producto;

public interface IProductoService  {
	
	public List<Producto> findAll();

	public Producto save(Producto producto);

	public Producto findById(Long codigo);

	public void delete(Long codigo);

}
